from grupo04 import limparTela

print('Limpando a tela')
print('Nova mensagem em tela limpa')