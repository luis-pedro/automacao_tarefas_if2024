import os
os.system('cls')

def limparTela():
    print('Nova mensagem em tela limpa')