cor = input('Digite uma cor (verde, amarelo, vermelho): ')

if cor == 'vermelho':
    print('pare')
elif cor == 'amarelo':
    print('atenção')
elif cor == 'verde':
    print('siga')